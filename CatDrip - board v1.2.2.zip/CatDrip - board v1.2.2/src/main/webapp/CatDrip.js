document
    .getElementById('toggle')
    .addEventListener("click", function () {
        if (document.querySelector('body').classList.contains('dark-mode')) {
            document
                .body
                .classList
                .remove("dark-mode");
        } else {
            document
                .body
                .classList
                .add("dark-mode");
        }
    }, false);

function detectColorScheme() {
    var theme = "light";

    if (localStorage.getItem("theme")) {
        if (localStorage.getItem("theme") == "dark") {
            var theme = "dark";
        }
    } else if (!window.matchMedia) {
        return false;
    } else if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
        var theme = "dark";
    }

    if (theme == "dark") {
        document
            .documentElement
            .setAttribute("data-theme", "dark");
    }
}
detectColorScheme();

const toggleSwitch = document.querySelector(
    '#theme-switch input[type="checkbox"]'
);

function switchTheme(e) {
    if (e.target.checked) {
        localStorage.setItem('theme', 'dark');
        document
            .documentElement
            .setAttribute('data-theme', 'dark');
        toggleSwitch.checked = true;
    } else {
        localStorage.setItem('theme', 'light');
        document
            .documentElement
            .setAttribute('data-theme', 'light');
        toggleSwitch.checked = false;
    }
}

toggleSwitch.addEventListener('change', switchTheme, false);

if (document.documentElement.getAttribute("data-theme") == "dark") {
    toggleSwitch.checked = true;
}


/////////////////////////////

function showPopup(){
    window.open("Login.html", "login", "width=565, height=520, left=650, top=200");
}

function clausePopup(){
    window.open("clause.html","SignUp", "width=600, height=400, left=650, top=200");
}

function PrivateDataPopup(){
    window.open("Private_Data.html", "Private_Data", "width=600, height=400, left=650, top=200");
}