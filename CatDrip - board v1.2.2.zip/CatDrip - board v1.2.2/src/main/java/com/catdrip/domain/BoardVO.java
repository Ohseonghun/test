package com.catdrip.domain;

import java.util.Date;

import lombok.Data;

@Data
public class BoardVO {
	int bno;
	String title;
	String content;
	String writer;
	int hit;
	Date regdate;
	Date updatedate;
}
